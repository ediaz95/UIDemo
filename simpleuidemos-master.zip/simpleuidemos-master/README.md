# Simple UI Demos
Misc demos: Some sample code that we created on the fly. Not production ready, but might be useful to look at if you 
listen to the video recording one more time.
